CLICKER LENDA — projeto Android

O jogo está pronto, com:
- clique para ganhar moedas
- melhorias de clique e produção automática
- seletor 1x, 2x, 10x, 50x, 100x e Max
- rebirth com multiplicador permanente
- salvamento automático local

IMPORTANTE:
Este pacote contém o PROJETO-FONTE Android, não um APK já compilado.
Para gerar o APK, abra a pasta ClickerLenda no Android Studio, aguarde a sincronização do Gradle e use:
Build > Build Bundle(s) / APK(s) > Build APK(s)

O APK de depuração será criado em:
app/build/outputs/apk/debug/app-debug.apk

Requisitos do projeto: Android SDK 35 e Android Gradle Plugin 8.6.1.
Também é possível abrir app/src/main/assets/index.html no navegador para jogar a versão web.
